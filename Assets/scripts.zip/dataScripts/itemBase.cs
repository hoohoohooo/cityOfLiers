﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class itemBase
{
    public int maxQuantity;
    public int count;
    public void checkQuantCount()
    {
        if (count > maxQuantity)
        {
            //do stuff
        }
    }
}
public class acid : itemBase
{
    public acid()
    {
        count = 1;
    }
}
