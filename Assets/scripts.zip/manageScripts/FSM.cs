﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class FSM : MonoBehaviour
{
    public List<npcAgents> agentList;
    // Start is called before the first frame update
    void Start()
    {
        foreach(npcAgents n in agentList)
        {
            if(n.curState == null)
            {
                //n.curState = new moveToState(n);
                //n.curState = new chaseState(gameMng.instance.player,n);
                n.curState = new idle(gameMng.instance.player, n);
                n.lastState = new moveToState(n);
                
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (agentList.Count > 0 || agentList != null) 
        {
            foreach(npcAgents n in agentList)
            {
                n.updateAgent();
            }
        }
    }
}

[System.Serializable]
public class npcAgents
{
    public states curState;
    public states lastState;
    public NavMeshAgent agentTrn;
    public List<Vector3> destinationPoints;
    public npcAgents()
    {
        //curState = new moveToState(this);
    }
    public void updateAgent()
    {
        curState.stateUpdate();
    }
}

public class states
{
    public npcAgents agent;
    public Transform plTrn;
    public enum stateType
    {
        idle,
        moveTo,
        search,
    }
    public stateType sType;
    public virtual void stateStart()
    {

    }
    public virtual void stateUpdate()
    {

    }
}

public class idle : states
{
    public idle(Transform trn, npcAgents nav)
    {
        plTrn = trn;
        agent = nav;
    }
    public override void stateUpdate()
    {
        Vector3 dir = plTrn.position - agent.agentTrn.transform.position;
        //base.stateUpdate();
        Debug.Log(Vector3.Dot(agent.agentTrn.transform.forward, dir));
    }
}

public class moveToState : states
{
    int loopIndex = 0;
    public float checkDist = 1f;
    public List<Vector3> destinationPoints;
    public Vector3 curDestination = Vector3.zero;
    

    public moveToState(npcAgents nav)
    {
        sType = stateType.moveTo;
        agent = nav;
        agent.agentTrn.speed = 3.5f;
        destinationPoints = nav.destinationPoints;
        curDestination = destinationPoints[0];
        agent.agentTrn.SetDestination(curDestination);
    }

    public bool checkArrival(Vector3 curpos,Vector3 dest)
    {
        if (Vector3.Distance(curpos, dest) < checkDist)
        {
            if (loopIndex < destinationPoints.Count)
            {
                loopIndex++;
            }
            if(loopIndex == destinationPoints.Count)
            {
                loopIndex = 0;
            }
            curDestination = destinationPoints[loopIndex];
            agent.agentTrn.SetDestination(curDestination);
            return true;
        }
        return false;
    }

    Ray ray;
    RaycastHit hit;
    Vector3 dir;

    public void checkPlayer()
    {

        dir = plTrn.position - agent.agentTrn.transform.position;
        if (Vector3.Dot(agent.agentTrn.transform.forward, dir) < 0)
        {
            return;
        }
        else
        {
            ray = new Ray(agent.agentTrn.transform.position, dir);
            if (Physics.Raycast(ray, out hit))
            {
                if (hit.transform == plTrn)
                {
                    if (hit.distance < 10)
                    {
                        agent.lastState = this;
                        chaseState tmp = new chaseState(plTrn, agent);
                        agent.curState = tmp;
                    }
                }
                else
                {
                    return;
                }
            }
        }
    }

    public override void stateStart()
    {
        //base.stateStart();
        agent.agentTrn.SetDestination(curDestination);
        agent.agentTrn.speed = 3.5f;
    }
    public override void stateUpdate()
    {
        //base.stateUpdate();
        
        checkPlayer();
        checkArrival(agent.agentTrn.transform.position,curDestination);
        
    }
}

public class chaseState : states
{
    public Transform target;
    Ray ray;
    Vector3 dir;
    RaycastHit hit;
    Vector3 lastDestination;
    float destDist = 0.5f;
    List<Vector3> playerPosList;
    float plTrackTimer = 0;
    float trackTime = 0.5f;
    public chaseState(Transform targ, npcAgents nav)
    {
        target = targ;
        agent = nav;
        playerPosList = new List<Vector3>();
    }
    public bool rayTarget()
    {
        dir = target.position - agent.agentTrn.transform.position;
        ray = new Ray(agent.agentTrn.transform.position, target.position);
        
        if (Physics.Raycast(agent.agentTrn.transform.position,dir,out hit))
        {
            Debug.DrawRay(agent.agentTrn.transform.position, dir, Color.red);
            if (hit.transform == target)
            {
                return true;
            }
        }
        else
        {
            
        }
        return false;
    }
    public void chaseTarget()
    {
        agent.agentTrn.SetDestination(target.position);
        lastDestination = target.position;
    }
    public void trackPlayer()
    {
        plTrackTimer += Time.deltaTime;
        if (plTrackTimer > trackTime)
        {
            plTrackTimer = 0;
            Vector3 tmp = target.position;
            playerPosList.Add(target.position);
            if (playerPosList.Count > 5)
            {
                playerPosList.Remove(playerPosList[0]);
            }
        }
        if (Vector3.Distance(agent.agentTrn.transform.position, playerPosList[0]) < destDist)
        {
            playerPosList.Remove(playerPosList[0]);
        }
        else
        {
            agent.agentTrn.SetDestination(playerPosList[0]);
        }
    }
    public override void stateUpdate()
    {
        //base.stateUpdate();
        if (rayTarget())
        {
            chaseTarget();
            if (Vector3.Distance(target.position, agent.agentTrn.transform.position) < destDist)
            {
                //hit player
            }
        }
        else if (Vector3.Distance(lastDestination, agent.agentTrn.transform.position) < destDist)
        {
            //to searchState
            //trackPlayer();
            searchState state = new searchState(target,ref agent);
        }
        else
        {
            
        }
    }
}

public class searchState : states
{
    //bool turn = false;
    float plTrackTimer = 0;
    float trackTime = 0.5f;
    List<Vector3> playerPosList;
    float destDist = 0.5f;

    float stateTimer = 0;
    float stateLimit = 4;

    public searchState(Transform pl, ref npcAgents nav)
    {
        plTrn = pl;
        playerPosList = new List<Vector3>();
        agent = nav;
        agent.curState = this;
        agent.agentTrn.speed = 1;
        
    }
    public void trackPlayer()
    {
        plTrackTimer += Time.deltaTime;
        if (plTrackTimer > trackTime)
        {
            plTrackTimer = 0;
            Vector3 tmp = plTrn.position;
            playerPosList.Add(plTrn.position);
            if (playerPosList.Count > 5)
            {
                playerPosList.Remove(playerPosList[0]);
            }
        }
        if (Vector3.Distance(agent.agentTrn.transform.position, playerPosList[0]) < destDist)
        {
            playerPosList.Remove(playerPosList[0]);
        }
        else
        {
            agent.agentTrn.SetDestination(playerPosList[0]);
        }
    }
    public override void stateUpdate()
    {
        //base.stateUpdate();
        trackPlayer();
        stateTimer += Time.deltaTime;
        if (stateTimer > stateLimit)
        {
            //end search;
            //agent.curState = agent.lastState;
            //agent.curState.plTrn = plTrn;
            //agent.curState.stateStart();
            moveToState tmp = new moveToState(agent);
            tmp.plTrn = plTrn;
            agent.curState = tmp;
            Debug.Log(stateTimer);
        }

    }

}